#include <w5100.cpp>
#include <socket.cpp>
#include <Dns.cpp>
#include <Dhcp.cpp>
#include <Ethernet.cpp>
#include <EthernetClient.cpp>
#include <EthernetServer.cpp>
#include <EthernetUdp.cpp>
