/* Stub for HardwareSerial.cpp */

#include <HardwareSerial.cpp>